<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="utf-8">
	<title>Aula 01 - Página 02</title>
</head>
<body>

	<h1>Página 02</h1>
	<p><a href="index.html">Voltar para página inicial</a></p>

	<!-- código php embutido: -->
	<?php 

	// mostrando algo na tela com o PHP (saída de dados)
	echo "<h1>Teste</h1>"; 
	// na saída de dados, qualquer comando html deve
	// ser tratado como uma string (conjunto de caracteres)

	echo "\n\tHello, world!";

	?>


</body>
</html>