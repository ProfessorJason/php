<nav>
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="sobre.php">Sobre mim</a></li>
		<li><a href="pg3.php">Página 3</a></li>
	</ul>
</nav>