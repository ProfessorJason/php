<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Aula 02 - Home</title>

	<link rel="stylesheet" type="text/css" href="css/meuestilo.css">
</head>
<body>

	<h1 class="titulo">Aula 02 - Home</h1>

	<?php include_once 'menu.php'; ?>

	<p class="texto">
		Esta é a pagina principal. <br>
		Utilize o menu para navegar entre as páginas
	</p>

	<p>
		Este parágrafo está recebendo a formatação padrão da página.
	</p>

</body>
</html>