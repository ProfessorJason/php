<nav class="menu">
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="exp1.php">Exemplo 1</a></li>
		<li><a href="exp2.php">Exemplo 2</a></li>
		<li><a href="exp3.php">Exemplo 3</a></li>
		<li><a href="exp4.php">Exemplo 4</a></li>
		<li><a href="exp5.php">Exemplo 5</a></li>
	</ul>
</nav>