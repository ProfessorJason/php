<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Aula 04 - home</title>
	<link rel="stylesheet" type="text/css" href="css/estilo.css">
</head>
<body>

	<h1>Aula 04 - Home</h1>

	<?php include_once 'menu.php'; ?>

	<p>
		Esta é a página principal. <br>
		Utilize o menu acima para navegar entre os exercícios de estruturas condicionais.
	</p>

</body>
</html>