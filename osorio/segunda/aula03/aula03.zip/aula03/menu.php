<nav class="menu">
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="ex1.php">Ex 01</a></li>
		<li><a href="ex2.php">Ex 02</a></li>
		<li><a href="ex3.php">Ex 03</a></li>
		<li><a href="ex4.php">Ex 04</a></li>
		<li><a href="ex5.php">Ex 05</a></li>
		<li><a href="ex6.php">Ex 06</a></li>
		<li><a href="ex7.php">Ex 07</a></li>
	</ul>
</nav>
