<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Aula 05 - classificação de mamófero</title>
	<link rel="stylesheet" type="text/css" href="../css/estilo.css">
</head>
<body>

	<h1>Classificando os mamíferos</h1>

	<form>
		
		<p>
			<label>O animal é quadrúpde?</label> 
			<select name="p1">
				<option value="1">SIM</option>
				<option value="2">NÃO</option>
			</select>
		</p>

		<p>
			<label>O animal é bípede?</label>
			<input type="radio" name="p2" value="1" checked> SIM 
			<input type="radio" name="p2" value="2"> NÃO
		</p>

	</form>


</body>
</html>