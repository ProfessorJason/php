<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Aula 01 - Hello World!</title>
</head>
<body>

	<h1>Página do Hello World</h1>

	<p align="center">
	<?php echo "Hello, world!"; ?>
	</p>

</body>
</html>