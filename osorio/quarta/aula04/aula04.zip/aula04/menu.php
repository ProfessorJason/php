<nav class="navbar">
	<ul>
		<li class="nav-item"><a class="nav-link" href="index.php">Home</a></li>
		<li class="nav-item"><a class="nav-link" href="ex1.php">Exercício 01</a></li>
		<li class="nav-item"><a class="nav-link" href="ex2.php">Exercício 02</a></li>
		<li class="nav-item"><a class="nav-link" href="ex4a.php">Exercício 04a</a></li>
		<li class="nav-item"><a class="nav-link" href="ex4b.php">Exercício 04b</a></li>
	</ul>
</nav>