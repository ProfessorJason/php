<nav class="menu">
	<ul class="menu_list">
		<li class="menu_li"><a class="menu_link" href="index.php">Home</a></li>
		<li class="menu_li"><a class="menu_link" href="exp1.php">Exemplo 1</a></li>
		<li class="menu_li"><a class="menu_link" href="exp2.php">Exemplo 2</a></li>
		<li class="menu_li"><a class="menu_link" href="ex1.php">Ex 01</a></li>
		<li class="menu_li"><a class="menu_link" href="ex2.php">Ex 02</a></li>
		<li class="menu_li"><a class="menu_link" href="ex3.php">Ex 03</a></li>
		<li class="menu_li"><a class="menu_link" href="ex4.php">Ex 04</a></li>
		<li class="menu_li"><a class="menu_link" href="ex5.php">Ex 05</a></li>
		<li class="menu_li"><a class="menu_link" href="ex6.php">Ex 06</a></li>
		<li class="menu_li"><a class="menu_link" href="ex7.php">Ex 07</a></li>
	</ul> 
</nav>