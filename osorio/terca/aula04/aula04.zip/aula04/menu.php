<nav class="navbar">
	<ul>
		<li class="navbar-item"><a href="index.php" class="navbar-link">Home</a></li>
		<li class="navbar-item"><a href="ex1.php" class="navbar-link">Ex 1</a></li>
		<li class="navbar-item"><a href="ex2.php" class="navbar-link">Ex 2</a></li>
		<li class="navbar-item"><a href="ex4.php" class="navbar-link">Ex 4</a></li>
		<li class="navbar-item"><a href="ex4b.php" class="navbar-link">Ex 4b</a></li>
	</ul>
</nav>