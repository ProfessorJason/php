<nav>
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="sobre.php">Sobre Mim</a></li>
		<li><a href="form.php">Formulário</a></li>
	</ul>
</nav>