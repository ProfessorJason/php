<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Aula 02 - Home</title>
	<link rel="stylesheet" type="text/css" href="css/meuestilo.css">
</head>
<body>
	
	<h1 class="titulo">Aula 02 - Home</h1>

	<?php include_once 'menu.php'; ?>

	<p class="texto">
		Esta é a página principal.<br>
		Para acessar as demais páginas, utilize o menu superior.
	</p>
	<p class="texto">
		Página feita por <b>Jason Sobreiro</b>.
	</p>

</body>
</html>