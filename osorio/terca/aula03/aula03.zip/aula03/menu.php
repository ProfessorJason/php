<nav class="menu">
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="exp1.php">Exemplo 01</a></li>
		<li><a href="exp2.php">Exemplo 02</a></li>
		<li><a href="ex1.php">Exercício 01</a></li>
		<li><a href="ex2.php">Exercício 02</a></li>
		<li><a href="ex3.php">Exercício 03</a></li>
		<li><a href="ex4.php">Exercício 04</a></li>
		<li><a href="ex5.php">Exercício 05</a></li>
		<li><a href="ex6.php">Exercício 06</a></li>
		<li><a href="ex7.php">Exercício 07</a></li>
	</ul>
</nav>
