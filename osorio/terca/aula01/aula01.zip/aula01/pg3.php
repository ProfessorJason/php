<?php

	// declaração das minhas primeiras variáveis
	$nome = "Jason Sobreiro"; // valor textual (string)	
	$idade = 34; // valor inteiro (int)

// echo = comando de saída, para mostrar algo na tela
	echo "<h3>Meu nome é $nome, e eu tenho $idade anos de vida!</h3>";