<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Aula 01 - Página 2</title>
</head>
<body>

	<h1>Página 02 (Contém código PHP)</h1>

	<?php 
		echo "Hello, world!<br>";
		echo "Página feita por <b>Jason Sobreiro</b>";
	?>

</body>
</html>