<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Aula 01 - Hello, World!</title>
</head>
<body>

	<h1>Página "Hello, world!"</h1>

	<p>
		<?php echo "Hello, world!"; ?>
	</p>

	<p>
		<a href="index.html">Voltar para a Home</a>
	</p>

</body>
</html>