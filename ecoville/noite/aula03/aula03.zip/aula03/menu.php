<nav class="menu">
	<ul class="menu-lista">
		<li class="menu-item"><a href="index.php">Home</a></li>
		<li class="menu-item"><a href="exp1.php">Exemplo 1</a></li>
		<li class="menu-item"><a href="exp2.php">Exemplo 2</a></li>
		<li class="menu-item"><a href="ex1.php">Ex 1</a></li>
		<li class="menu-item"><a href="ex2.php">Ex 2</a></li>
	</ul>
</nav>