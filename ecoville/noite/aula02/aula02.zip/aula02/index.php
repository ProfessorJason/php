<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Aula 02 - Home</title>
	<link rel="stylesheet" type="text/css" href="css/meuestilo.css">
</head>
<body>

	<h1>Aula 02 - Home</h1>

	<?php include_once 'menu.php'; ?>

	<p>
		Esta é a página principal do site.<br> 
		Para acessar as outras páginas, utilize o menu acima.
	</p>

</body>
</html>