<nav>
	<ul>
		<li><a href="index.php">Home</a></li>
		<li><a href="sobre.php">Sobre Mim</a></li>
		<li><a href="cadastro.php">Cadastro</a></li>
	</ul>
</nav>