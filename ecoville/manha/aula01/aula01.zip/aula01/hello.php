<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Aula 01 - Hello World</title>
</head>
<body>

	<h1>Página PHP com Hello, World!</h1>

	<?php echo "Hello, world!"; ?>

	<p>
		<a href="index.html">Voltar para home</a>
	</p>

</body>
</html>