<nav class="menu">
	<ul class="menu_lista">
		<li class="menu_item"><a href="index.php">Home</a></li>
		<li class="menu_item"><a href="exp1.php">Exemplo 01</a></li>
		<li class="menu_item"><a href="exp2.php">Exemplo 02</a></li>
		<li class="menu_item"><a href="ex1.php">Ex 1</a></li>
	</ul>
</nav>